#Python is an object oriented programming language.
#Almost everything in Python is an object, with its properties and methods.
#A Class is like an object constructor, or a "blueprint" for creating objects.

#Make a Checking Account
#All classes have a function called __init__(),
#which is always executed when the class is being initiated.
#Use the __init__() function to assign values to object properties,
#or other operations that are necessary to do when the object is being created:
#The __init__() function is called automatically every time the class is being used to create a new object.
class checking:
    def __init__(self, amt):
        print("You have opened a checking account with ", amt)
        self.balance = amt
        #"Creating an instance variable": Variables that only count for one object that you created
        #We call it self as we don't have a variable name

#Getter and Setter-methods
    def getBalance(self):
        return self.balance

    def deposit(self, amt):
        self.balance += amt
        print("You have deposited", amt)
        print("Your new balance is:", self.balance)

    def withdraw(self, amt):
        if amt > self.balance:
            print("Insufficient Funds")
            print("Balance:", self.balance)
        else:
            self.balance -= amt
            print("You have withdrawn:", amt)
            print("Balance:", self.balance)

#test things
#Instances-MyAcct: A variable that point to the object called "checking"
MyAcct = checking(300)
print(MyAcct.getBalance())

MyAcct.deposit(500)

#We can take the blue print and create as many objects as we want
BobAcct = checking(1000)
print(MyAcct.getBalance(), BobAcct.getBalance())

MyAcct.withdraw(900)
