
# Crypto Keeper Library

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import matplotlib.dates as dates
import matplotlib
import Data   #get data


# Superclass
class Currency():

    def __init__(self,data):
        self.data = data

        self.data_3m =  self.data.loc[(self.data['Date'] >= '2018-01-16') & (self.data['Date'] <= '2018-04-16')]   # 3 months data
        self.data_6m =  self.data.loc[(self.data['Date'] >= '2017-10-16') & (self.data['Date'] <= '2018-04-16')]    # 6 months data
        self.data_12m =  self.data.loc[(self.data['Date'] >= '2017-04-16') & (self.data['Date'] <= '2018-04-16')]    # 12 months data
        self.data_24m =  self.data.loc[(self.data['Date'] >= '2016-04-16') & (self.data['Date'] <= '2018-04-16')]   # 24 months data


    def get_data(self, period):

        #period must be 3, 6, 12, or 24

        if (period <= 3):
            return self.data_3m
        elif(period <= 6):
            return self.data_6m
        elif(period <= 12):
            return self.data_12m
        elif(period <= 24):
            return self.data_24m
        else:
            return self.data

    def get_data_by_date(self, starting_date, ending_date):

       # starting_date and ending_date must be the form of "YYYY-MM-DD"

        return self.data.loc[(self.data['Date'] >= starting_date) & (self.data['Date'] <= ending_date)]

    def get_min(self, period):
        p_data = self.get_data(period)

        return '${:,.2f}'.format(p_data.iloc[:, 1].min())
        #.2f is a placeholder for floating point number
        #$ means that you're supposed to be in your system shell.
        #But your shell has access to a command named python.
        #http://www.compciv.org/guides/devwork/code-conventions/

    def get_max(self, period):
        p_data = self.get_data(period)

        return '${:,.2f}'.format(p_data.iloc[:, 1].max())
        #iloc gets rows (or columns) at particular positions in the index (so it only takes integers).

    def get_avg(self, period):
        p_data = self.get_data(period)

        return '${:,.2f}'.format(p_data.iloc[:, 1].mean())

    def get_std(self, period):
        p_data = self.get_data(period)

        return '${:,.2f}'.format(p_data.iloc[:, 1].std())

    def crt_price(self): # displays the current price (2018-04-15)
        self.price = self.data.iloc[-1]['Price']

        return '${:,.2f}'.format(self.price)

    #calculate % change in price - latest vs. oldest
    def p_chg(self,period):
        p_data = self.get_data(period)
        old_p = p_data.iloc[0]['Price']
        new_p = p_data.iloc[-1]['Price']
        p_chg = (new_p - old_p)/old_p

        return '{:.2%}'.format(p_chg)

    #calcualte SMA
    def SMA(self, period):

        data = self.get_data(period).iloc[:, 1]

        if (period <= 3):
            n = 10
        elif(period <= 6):
            n = 15
        elif(period <= 12):
            n = 30
        elif(period <= 24):
            n = 45

        rolling = data.rolling(n).mean()
        return rolling

    #defining the interval for SMA graph
    def interval(self,period):

        if (period <= 3):
            n = 1
        elif(period <= 6):
            n = 2
        elif(period <= 12):
            n = 5
        elif(period <= 24):
            n = 6

        return n

    #calculate projected % return based on the past 30 days info
    def proj_chg(self):
        data = self.get_data_by_date("2018-03-16","2018-04-15")['Price']
        a = data.pct_change(1)
        b = 0
        for i in range(1,7):
            b += a.iloc[i]
        c = (1+b)**(1/6)-1 #get geometric mean of % change
        d = c.tolist() # convert numpy.float to float
        return d

    #Histogram
    def hist(self,period):
        p_data = self.get_data(period)
        p_data.hist(column = 'Price')
        plt.ylabel("Frequency")
        plt.show()

    #calculate Log Returns
    def log(self,period):
        df = self.get_data(period).iloc[:,0:2]
        df.set_index('Date',inplace = True)
        df['Price'] = np.log(df['Price']/df['Price'].shift())
        return df

#subclass
class Bitcoin(Currency):

    def __init__ (self,data,name):
        Currency.__init__(self,data)
        self.name = name

    #redefine the hist method
    def hist(self,period):
        p_data = self.get_data(period)
        fig,ax = plt.subplots(figsize=(14,7))
        p_data.hist(column = 'Price',ax=ax)
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.xaxis.set_major_formatter(tick)
        plt.ylabel("Frequency")
        plt.xlabel("Price")
        plt.title("Histogram of " + self.name +" Price")
        plt.show()

    def plot_SMA(self,period):
        n = self.interval(period)

        df1 = self.get_data(period).iloc[:,0:2]
        df2 = self.SMA(period)
        frames = [df1,df2]
        result = pd.concat(frames,axis =1, join_axes=[df1.index])

        fig,ax = plt.subplots(figsize=(13,6))
        result.plot(x = 'Date',ax=ax)
        L = plt.legend()
        L.get_texts()[1].set_text('SMA')
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.yaxis.set_major_formatter(tick)
        ax.xaxis.set_major_locator(dates.WeekdayLocator(byweekday=(n),interval=n))
        ax.xaxis.set_major_formatter(dates.DateFormatter('%b %d'))
        plt.title("Historical Price and SMA Graph of " + self.name)
        plt.show()

#subclass
class Ethereum(Currency):

    def __init__ (self,data,name):
        Currency.__init__(self,data)
        self.name = name

    def hist(self,period):
        p_data = self.get_data(period)
        fig,ax = plt.subplots(figsize=(14,7))
        p_data.hist(column = 'Price',ax=ax)
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.xaxis.set_major_formatter(tick)
        plt.ylabel("Frequency")
        plt.xlabel("Price")
        plt.title("Histogram of " + self.name +" Price")
        plt.show()

    def plot_SMA(self,period):
        n = self.interval(period)

        df1 = self.get_data(period).iloc[:,0:2]
        df2 = self.SMA(period)
        frames = [df1,df2]
        result = pd.concat(frames,axis =1, join_axes=[df1.index])

        fig,ax = plt.subplots(figsize=(13,6))
        result.plot(x = 'Date',ax=ax)
        L = plt.legend()
        L.get_texts()[1].set_text('SMA')
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.yaxis.set_major_formatter(tick)
        ax.xaxis.set_major_locator(dates.WeekdayLocator(byweekday=(n),interval=n))
        ax.xaxis.set_major_formatter(dates.DateFormatter('%b %d'))
        plt.title("Historical Price and SMA Graph of "+ self.name)
        plt.show()

#############################################################################

#Functions

#Phase 1
#
#
def stat(coin,period):
    print("Today's price: ",coin.crt_price())
    print("The highest was: ",(coin.get_max(period))) #return a date
    print("The lowest was:  ", coin.get_min(period))
    print("The average is: ",coin.get_avg(period))
    print("Std deviation is: ",coin.get_std(period))
    print("% change in price is: ",coin.p_chg(period))


#Phase 2
#
#
def comparison(coin1,coin2,period):
    coin1.plot_SMA(period) #show SMA graph
    coin2.plot_SMA(period)
    plot_log(coin1,coin2,period)  #return the log returns graph
    plot_Hist(coin1,coin2,period)   #return the Hist of Volumes of the two
    conclu1 = ("\nConclusion: \n")
    conclu2 = ("Based on the log return analysis for your selected time range,\n"
    "we can conclude that Bitcoin is a safer investment due to its less volatile fluctuations.\n"
    "When comparing price against SMA, it is safe to buy in when price trends exceed SMA. When the values\n"
    "intersect, there is no discernable difference whether you buy in or cash out.\n"
    "Alternatively, you can wait and see if trends change before making a decision.\n"
    "According to Histogram of volume between the two currencies, Bitcoin in a better choice:\n  "
    "Volume refers to the total dollar value of trading happened in a day. The higher the volume the more popular the currency.\n "
    "High popularity usually comes hand in hand with high demand and fluidity – both factors have positive impact on the price of the currency.\n "
    "As we can see form the histograph, even Ethereum shows has a few trading days with significant high volume at more than 6 billion dollars,\n"
    "Bitcoin surpass the total by having more active trading days.\n "
    "Therefore, Bitcoin is recommended based on volume.\n")

    print(conclu1 + conclu2)
    #output to txt
    ofile = open("Conclusion.txt","w")
    ofile.write(conclu1 + conclu2)


#plot log returns of 2 crypto
def plot_log(bit,eth,period):
    dfb = bit.log(period)
    dfe = eth.log(period)
    frames = [dfb,dfe]

    loggraph = pd.concat(frames,axis = 1,join_axes=[dfb.index])
    fig,ax = plt.subplots(figsize=(14,7))
    loggraph.plot(ax=ax)
    ax.yaxis.set_major_formatter(mtick.PercentFormatter(10.0))
    L = plt.legend()
    L.get_texts()[0].set_text('Bitcoin')
    L.get_texts()[1].set_text('Ethereum')
    plt.title("Bitcoin and Ethereum Log Returns")
    plt.show()


#plot histogram of volumes for 2 crypto
def plot_Hist(bit,eth,period):

    dfb = bit.get_data(period)
    dfb.set_index('Date',inplace = True)
    dfe = eth.get_data(period)
    dfe.set_index('Date',inplace = True)
    frames = [dfb,dfe]
    df = pd.concat(frames,axis = 1,join_axes=[dfb.index])
    df = df['Volume']

    fig,ax = plt.subplots(figsize=(13,6))

    df.plot(ax = ax, kind = 'hist')
    plt.xlabel("Volume (in billions)")
    plt.ylabel("Frequency (Days)")
    plt.title("Histogram of Bitcoin and Ethereum Volume")

    L = plt.legend()
    L.get_texts()[0].set_text('Bitcoin')
    L.get_texts()[1].set_text('Ethereum')

    plt.show()

#Phase 3
#
#
def invest(btc,eth,allobtc,alloeth,amt):
    b = btc.proj_chg() # projected % change for btc
    amt_b = allobtc * amt # allocated amount for btc
    est_b = amt_b * b # estimated profit/loss for  btc

    e = eth.proj_chg() # projected % change for eth
    amt_e = alloeth *amt # allocated amount for eth
    est_e = amt_e * e # estimated profit/loss for eth

    print("The projected % return for Bitcoin is ",'{:.2%}.'.format(b))
    print("The projected % return for Ethereum is ",'{:.2%}.'.format(e))
    print ("You are investing",'${:,.0f}'.format(amt_b), "in Bitcoin and",'${:,.0f}'.format(amt_e), "in Ethereum.")
    print("With",'${:,.0f},'.format(amt), "your total estimated return is",'${:,.2f}.'.format(est_b + est_e))
    print("Your return on Bitcoin:is", '${:,.2f}.'.format(est_b))
    print("Your return on Ethereum is",'${:,.2f}.'.format(est_e))



# constant - for default allocation % in phase 3
d_alloc = 0.5

