# Crypto Keeper Main Program

from Currency import *

    
def main():

    print("_______________________________Crypto Keeper____________________________________")
    intro = ("This program will give you an overview of the selected cryptocurrency's "
             "respective performance and suggest you which one is a better option for "
             "investment based on centain metrics.\n")
    print(intro)
    answer = 'yes'
    while answer.lower() == 'yes':

    # Phase 1

        print("_________________________________ Phase 1_______________________________________")
        choice = input(str("Which cryptocurrency are you interested in?(Bitcoin/Ethereum): "))
     
        period = int(input("Please select a time frame (3/6/12/24) months: "))
        print('\n')    

        if choice.lower() == "bitcoin":
              coin = Bitcoin(Data.bitdata,"Bitcoin")
              
        elif choice.lower() == 'ethereum':
              coin = Ethereum(Data.ethdata,"Ethereum")


        print("________________Statistical information of", choice.lower(),"over",period,"months________________\n")
        stat(coin,period)
        coin.plot_SMA(period)
        coin.hist(period)
        

    # Phase 2
        print("\n__________________________________ Phase 2_______________________________________")
        btc = Bitcoin(Data.bitdata,"Bitcoin")
        eth = Ethereum(Data.ethdata,"Ethereum")
        
        test = input("Would you like to run a comparison report? (Yes/No): ") 
        if (test.lower() == "yes"):
           comparison(btc,eth,period)
           
  
    # Phase 3
        print("\n__________________________________ Phase 3_______________________________________")
        
        inv = str(input("Would you like to invest?(Yes/No): "))

        if (inv.lower() == "yes"):
            amt = int(input("Insert your investment amount: "))

            print("\nEstimates are based on the past 30 days.")
            
            print("\nAssuming 50% allocation")
            invest(btc,eth,d_alloc,d_alloc,amt)
            
            allobtc = float(input("\nWhat's your allocation for Bitcoin(Enter a decimal): "))

            
            if allobtc  <= 1:
                alloeth = 1 - allobtc
                invest(btc,eth,allobtc,alloeth,amt)
            else:
                allobtc = float(input("% amount should be less or equal to 1: "))
            
        
        print('\n')
        print("Thank you for using Crypto Keeper.")

        answer = input("Would you like to run it again? (Yes/No): ")
        print('\n')


    
if __name__ == "__main__":
    main()
