import Currency
import Data

Hist_Choice = input(str("Do you want to view the Histogram of Volume?"))
Hist_period = int(input("Time frame?(3/6/12/24 months): \n"))

if Hist_Choice.lower() == "yes":
    bit_v = Data.bitdata
    eth_v = Data.ethdata

#Output
    Hist_Compare = open("Hist_Comp.txt","w")
    Hist_Compare.write("Bitcoin is a better choice")
    Hist_Compare.close()


SMA_Choice = input(str("Do you want to view the SMA of Bitcoin and Ethereum"))
SMA_period = int(input("Time frame?(3/6/12/24 months): \n"))
if Hist_Choice.lower() == "yes":

#Output
    SMA_Compare = open("SMA_Comp.txt","w")
    SMA_Compare.write("Bitcoin is a better choice")
    SMA_Compare.close()

print(Currency.plot_Hist(bit_v,eth_v,Hist_period))

