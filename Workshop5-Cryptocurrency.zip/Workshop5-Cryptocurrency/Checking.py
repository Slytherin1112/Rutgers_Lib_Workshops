#Python is project oriented
#Checking Account

'''
class checking:
    def __init__(self):
        print("You have an opening balance of:", amt)
        self.balance = amt
        #"Create an instance variable": Variables that only count for this one object
        #We call "self" as we dont have a variable name

#getter and setter
    def getBalance(self):
        return self.balance

    def deposit(self, amt):
        self.balance += amt
        print("You have deposited:", amt)
        print("Your new balance is:", self.balance)

    def withdraw(self, amt):
        if amt > self.balance:
            print("Insufficient Balance")
            print("Balance:", amt)
        else:
            self.balance -= amt
            print("You have withdrawn:", amt)
            print("Your remaining balance:", self.balance)

#test things
#Instance: A variable that point the object "checking"
MyAcct = checking(900)
#print(MyAcct.getBalance())

MyAcct.deposit(300)
MyAcct.withdraw(200)

BobAcct = checking(10000)

print(BobAcct.getBalance(), MyAcct.getBalance())
'''
#Creat a savings acct that can only deposit
#YournameAcct (2000)
#Deposit 1000
'''
class saving:
    def __init__(self, amt):
        print("You have opened a saving account with ", amt)
        self.balance = amt

    # Getter and Setter-methods
    def getBalance(self):
        return self.balance

    def deposit(self, amt):
        self.balance += amt
        print("You have deposited", amt)
        print("Your new balance is:", self.balance)

    def withdraw(self, amt):
        print("You cannot withdraw from your saving account")


JesseAcct = saving(2000)
print(JesseAcct.getBalance())
JesseAcct.deposit(1000)
JesseAcct.withdraw(2000)
'''


class SavingAcct():
    def __init__(self, amt):
        self.balance = amt
        print('The current balance is: ' + str(self.balance))

    def deposit(self, amt):
        self.balance += amt
        print('The current balance is: ' + str(self.balance))


if __name__ == "__main__":
    MyAcct = SavingAcct(2000)
    MyAcct.deposit(1000)
