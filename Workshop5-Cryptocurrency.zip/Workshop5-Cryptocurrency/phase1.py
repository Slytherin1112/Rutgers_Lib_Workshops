from Currency import *
from matplotlib import interactive

# phase 1 function

#subclass 
class Bitcoin(Currency):

    def __init__ (self,data,name,end_date = None):
        if end_date == None:
            end_date = '2018-04-16'
        Currency.__init__(self,data,end_date)
        self.name = name

    def hist(self,period):
        p_data = self.get_data(period)
        fig,ax = plt.subplots(figsize=(14,7))
        p_data.hist(column = 'Price',ax=ax)
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.xaxis.set_major_formatter(tick)
        plt.ylabel("Frequency")
        plt.xlabel("Price")
        plt.title("Histogram of Bitcoin Price")
        plt.show()
        
class Ethereum(Currency):

    def __init__ (self,data,name,end_date = None):
        if end_date == None:
            end_date = '2018-04-16'
        Currency.__init__(self,data,end_date)
        self.name = name

    def hist(self,period):
        p_data = self.get_data(period)
        fig,ax = plt.subplots(figsize=(14,7))
        p_data.hist(column = 'Price',ax=ax)
        fmt = '${x:,.0f}'
        tick = mtick.StrMethodFormatter(fmt)
        ax.xaxis.set_major_formatter(tick)
        plt.ylabel("Frequency")
        plt.xlabel("Price")
        plt.title("Histogram of Ethereum Price")
        plt.show()

    
def stat(coin,period):
    print("Today's price: ",coin.crt_price())
    print("The highest was: ",(coin.get_max(period))) #return a date
    print("The lowest was:  ", coin.get_min(period))
    print("The average is: ",coin.get_avg(period))
    print("Std deviation is: ",coin.get_std(period))
    print("% change in price is: ",coin.p_chg(period))
    
    
def main():

# below is for phase 1 

    print("_______________________Crypto Keeper____________________________________")
   # print("This program will give you an overview of the selected cryptocurrency.sep='',")
    choice = input(str("Which cryptocurrency are you interested in? (Bitcoin/Ethereum): \n"))
 
    period = int(input("Time frame?(3/6/12/24 months): \n"))
    print('\n')

    timeframe_temp = input(str("Please input the END date of the period you would like to know more about in yyyy-mm-dd Example: 2018-04-16 \n Type 'default' otherwise."))
    end_date = None
    if(timeframe_temp.lower() == 'default'):
        end_date = '2018-04-16'
    else:
        try:
            splits = timeframe_temp.split('/')
            if(    (int(splits[0]) < 2016 or int(splits[0]) > 2019) or
                   (int(splits[1]) < 1 or int(splits[1]) > 12) or
                   (int(splits[2]) < 1 or int(splits[2] > 31))):
                raise
            else:
                end_date = timeframe_temp
        except:
            return("Invalid date format.")

    if choice.lower() == "bitcoin":
          coin = Bitcoin(Data.bitdata,"bitcoin",end_date)
    elif choice.lower() == 'ethereum':
          coin = Ethereum(Data.ethdata,"ethereum",end_date)

   # print(coin.get_describe(period))
    print("********statistical information of", choice.lower(),"over",period,"months*******")
    stat(coin,period)
    interactive(True)
    coin.plot_SMA(period)
    coin.hist(period)
    
if __name__ == "__main__":
    main()
