# Compare 2 major Cryptocurrencies - Bitcoin & Ethereum
#5yrs Bitcoin
#4yrs Ethereum (First released on July30, 2015)
#Get data from Yahoo finance
#Volumn: Trading amount per day


import pandas as pd
#from pandas import DataFrame, read_csv

file1 = 'PythonBitData.csv'
file2 = 'PythonEthData.csv'

#pandas can automatically recognize dates
bitdata= pd.read_csv(file1,skiprows = 1,parse_dates = ['Date'])
ethdata= pd.read_csv(file2,skiprows=1, parse_dates = ['Date'])

print(bitdata)
print(ethdata)